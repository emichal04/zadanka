<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="emichal04">
    <link rel="stylesheet" href="styl_1.css" type="text/css">
    <title>Wędkujemy</title>
</head>
<body>
    <header>
        <div class="baner">
            <h1>Portal dla wędkarzy</h1>
        </div>
    </header>
    <main>
        <div class="flex">
            <div class="lewy">
                <section>
                    <header><h2>Ryby drapieżne naszych wód</h2></header>
                    <ul>
                        <?php
                            $polacz = mysqli_connect("localhost", "root", "", "wedkowanie");
                            $sql = "SELECT nazwa,wystepowanie FROM ryby WHERE styl_zycia=1;";
                            $rezultat = mysqli_query($polacz, $sql);
                            
                            while ($row=mysqli_fetch_row($rezultat)) {
                                echo "
                                <li><strong>$row[0]</strong> występuje w: <i>$row[1]</i></li>
                                    ";
                            }
                            
                            mysqli_close($polacz);
                        ?>
                    </ul>
                </section>
            </div>
            <div class="prawy">
                <section>
                    <img src="ryba1.jpg" alt="Sum"><br>
                    <a href="kwerendy.txt" class="link">Pobierz kwerendy</a>
                </section>
            </div>
        </div>
    </main>
    <footer>
        <div class="baner">Stronę wykonał: emichal04</div>
    </footer>
</body>
</html>
