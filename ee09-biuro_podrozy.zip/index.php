<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wycieczki i urlopy</title>
    <link rel="stylesheet" href="styl3.css" type="text/css">
</head>
<body>
    <header>
        <div class="panel">
            <h1>BIURO PODRÓŻY</h1>
        </div>
    </header>
    <main>
        
        <section>
            <div class="flex">
                <div class="lewy">
                    <header><h3>KONTAKT</h3></header>
                    <a href="mailto:biuro@wycieczki.pl?subject=Napisz do nas!">Napisz do nas</a>
                    <p>Telefon:555666777</p>
                </div>
                <div class="srodkowy">
                    <br>
                    <header><h3>GALERIA</h3></header><br>
                    <?php
                    $db = new mysqli('localhost', 'root', '', 'egzamin');
                    $db->set_charset('utf8');
                    $sql =  "SELECT nazwaPliku, podpis FROM `zdjecia` ORDER BY podpis ASC";
                    $result = $db->query($sql);
                    while ($row = $result->fetch_assoc()) {
                        $src = $row['nazwaPliku'];
                        $alt = $row['podpis'];
                        echo "<img src=\"$src\" alt=\"$alt\" style=''>";
                    }
                    ?>
                 </div>
                <div class="prawy">
                    <header><h3>PROMOCJE</h3></header>
                    <table>
                        <tr>
                            <td>Jesień</td>
                            <td>Grupa 4+</td>
                            <td>Grupa 10+</td>
                        </tr>
                        <tr>
                            <td>3%</td>
                            <td>12%</td>
                            <td>18%</td>
                        </tr>
                    </table>
                </div>
            </div>
        </section>

        <section>
            <div class="dane">
                <h3>LISTA WYCIECZEK</h3>
                <?php
                $baza = "SELECT dataWyjazdu,cel,cena FROM `wycieczki` WHERE dostepna = 1";
                $wynik = $db->query($baza);
                while ($row = $wynik->fetch_assoc()) {
                    $id = $row['id'];
                    $dataWyjazdu = $row['dataWyjazdu'];
                    $cel = $row['cel'];
                    $cena = $row['cena'];
                    echo "<p>$dataWyjazdu, $cel, cena: $cena zł</p>";
                }
                $baza = "SELECT dataWyjazdu,cel,cena FROM `wycieczki` WHERE dostepna = 0";
                $wynik = $db->query($baza);
                while ($row = $wynik->fetch_assoc()) {
                    $id = $row['id'];
                    $dataWyjazdu = $row['dataWyjazdu'];
                    $cel = $row['cel'];
                    $cena = $row['cena'];
                    echo "<p class='niedostepna'>$dataWyjazdu, $cel, cena: $cena zł</p>";
                }
                $db->close();
                ?>
                <br>
            </div>
        </section>

    </main>
    <footer>
        <div class="panel">
            <p>Stronę wykonał: 0</p>
        </div>
    </footer>
</body>
</html>